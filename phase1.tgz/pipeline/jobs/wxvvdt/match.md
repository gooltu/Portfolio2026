# Match: LinkedIn, Staff Product Designer, Talent Enterprise (Bengaluru)

Fit: strong on enterprise, data-rich, AI prototyping, mentoring and platform thinking. Two soft spots below.

| JD requirement | Evidence (claim ids) |
|---|---|
| Degree (MDes/HCI) | MDes IIT Kanpur (timeline) |
| 8+ yrs product lifecycle | 13+ yrs UX (counting rules) |
| Figma + prototyping | tools list; tf-claude-code, northstar-vscode |
| Rapid AI prototyping | tf-claude-code, northstar-vscode (Claude Code, Helios MCP) |
| Data-rich experiences | memprof-data, instana-standards, otel-oecc |
| Multiple personas | personas-four, ia-pas, interviews |
| Systems that scale | ds-delivery, ds-pipeline, consul-wcag |
| Mentoring, craft bar | team-growth, team-rituals |
| Strategy and vision | northstar-vscode, instana-standards, oecc-adoption |
| Large-scale independent delivery | tf-adoption, oecc-adoption |
| Stakeholders, ambiguity | tf-research, personas-jira |

## Gaps (reported, not filled)
- **Talent / HR / recruiting domain:** no evidence in the fact bank. The letter frames the match as enterprise, data-rich and AI-assisted workflow design, not talent products.
- **Founding a new regional team:** no evidence of founding a site. Closest is growing a distributed team from 2 to 7 (team-growth).
- **Visual design / infographics:** thin; the portfolio shows interaction and systems work more than visual craft.
- **Reports and data tables as such:** dashboards and graphs are supported; "reports" and "tables" are not named in the bank.
- Bangalore location: not stated in the fact bank, so not claimed.
