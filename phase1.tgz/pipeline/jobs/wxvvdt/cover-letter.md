Dear Hiring Team,

The Talent Enterprise team is asking for a designer who can turn data-rich, AI-powered enterprise workflows into something clear and consistent across a platform. That is the work I have done for 13+ years in UX, most recently on HashiCorp Terraform and on Progress OpenEdge.

The closest match is the Terraform upgrade experience I designed end to end with agentic AI flows. Adoption of the latest Terraform across HCP workspaces rose from 33% to 80%+ within two months of release. I prototyped it with Claude Code and the Helios Design System MCP server, which is how I work when an idea needs to become a functional prototype quickly. Before that, I launched the AI-enabled Memory Profiler, a data-dense developer tool with live memory graphs and snapshot comparison, which cut memory-related support calls and forum inquiries by 50%.

You also ask for leadership and systems thinking. At Progress I grew a distributed design team from 2 to 7 across the US, Bulgaria and India, with weekly reviews and 1:1s and every designer owning a product area. I established a WCAG 2.2 AA design system that accelerated delivery by 30%, and I developed four personas, from 50+ customer interviews across 25 customers, that are now used across the company. My work has reached 250K businesses across Progress and HashiCorp.

My portfolio is at mayukhonline.in. I would be glad to walk you through the case studies whenever it suits you.

Regards,
Mayukh Chakraborty
